// import firebase from 'firebase/compat/app';
// import 'firebase/compat/firestore';
// import 'firebase/compat/storage';

// const config = {
//     apiKey: "AIzaSyBgayYzyvYHebUFyQYGKfAVHdL7X_VlxEs",
//     authDomain: "ms-shopper-0.firebaseapp.com",
//     projectId: "ms-shopper-0",
//     storageBucket: "ms-shopper-0.appspot.com",
//     messagingSenderId: "463349562510",
//     appId: "1:463349562510:web:9fd0074bbbd3b0d6e55ddf",
//     measurementId: "G-1E2VQHT79D"
//   };
// firebase.initializeApp(config)
// firebase.firestore().settings({
// })

// export const myFirebase = firebase
// export const myFirestore = firebase.firestore()
// export const myStorage = firebase.storage()
